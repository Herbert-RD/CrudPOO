package br.com.lecharmeapi.lecharmeapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeCharmeApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LeCharmeApiApplication.class, args);
	}
}
